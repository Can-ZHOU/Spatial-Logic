This README file briefly explains how to configure and use AOD for
ontology debugging.


I. AOD Ontology Format

An ontology for AOD contains a list of either concept definition axioms
or concept instances, as described below.

 - Concept definition axiom: [CONCEPT_NAME implies CONCEPT_DESCRIPTION]

 - Concept instance: [CONCEPT_DESCRIPTION i] where i is a valid word

where CONCEPT_DESCRIPTION = atom CONCEPT_NAME or one of the following:

 - Conjunction of concept descriptions [and [CONCEPT_DESC1 CONCEPT_DESC2
 ... CONCEPT_DESCn]]

 - Disjunction of concept descriptions [or [CONCEPT_DESC1 CONCEPT_DESC2
 ... CONCEPT_DESCn]]

 - Universal restriction: [forall ROLE_NAME CONCEPT_DESCRIPTION]

 - Existential restriction: [exists ROLE_NAME CONCEPT_DESCRIPTION]

 - Concept Negation: [not CONCEPT_DESCRIPTION]

The ontology must be declared as a global variable using the Pop-11
'var' keyword. The following is a simple example ontology readable by
AOD:

vars ontology = [
[A5 implies [exists R2 [exists R0 [exists R3 [atom B6] ]]]]
[A4 implies [exists R0 [exists R5 [and [ [not atom A1 ][not atom B6 ]]]]]]
[A3 implies [forall R4 [exists R5 [and [ [atom B6] [not atom B0 ]]]]]]
[A2 implies [exists R6 [exists R1 [forall R5 [not atom B0 ]]]]]
[A2 c]
];


II. Running AOD (on a Linux machine)

1. Download and install Poplog and Poprulebase from
http://www.cs.bham.ac.uk/research/projects/poplog/freepoplog.html

By default, the installation scripts will install poplog in
/usr/local/poplog/current-poplog/bin/poplog (the install scripts allow
you to choose a different installation directory)

2. Extract the AOD code from compressed tar file to a folder (eg,
~/datms/)

3. Run pop11 with the following arguments in a terminal:

pop11 uALC_rules.p <ontology-file> <unsatisfiable-concept-list>

For example, to run the code with the Geography_Disjoint ontology file
and 2 unsatisfiable concept names VOLCANICMOUNTAIN and RIVER:

pop11 uALC_rules.p Geography_Disjoint VOLCANICMOUNTAIN RIVER
